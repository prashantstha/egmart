# egmart
egmart html slicing
